<?php
$dsn = "mysql:host=localhost;dbname=seller";
$username = "root";
$password = "";
//$database = "seller";
try {
    $conn = new PDO($dsn, $username, $password);
}catch(PDOException $e){
    die( "Connection failed: " . $e->getMessage());
}
