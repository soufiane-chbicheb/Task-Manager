<?php
include_once("connection.php");
$error = [];

if (isset($_POST["submit"])) {
    if (!empty($_POST["name"])) {
        $name = htmlspecialchars($_POST["name"]);
    } else {
        $error["nameErr"] = "Name of the product should not be empty";
    }

    if ($_FILES["image"]["error"] === 0 ) {
        $nameimage = $_FILES["image"]["name"];
        $tmpname = $_FILES["image"]["tmp_name"];
        move_uploaded_file($tmpname, "uploads/".$nameimage);
    } else {
        $error["imageErr"] = "Image of the product should not be empty";
    }

    if (!empty($_POST["price"])) {
        $price = htmlspecialchars($_POST["price"]);
    } else {
        $error["priceErr"] = "Price of the product should not be empty";
    }
    if (!empty($_POST["categorie"])) {
        $cat_id = htmlspecialchars($_POST["categorie"]);
    } else {
        $error["catIdErr"] = "you should select a category";
    }
    if (empty($error)) {
//        $name = mysqli_real_escape_string($conn, $name);
//        $price = mysqli_real_escape_string($conn, $price);
//        $image = mysqli_real_escape_string($conn, $image);
        $stmt = $conn->prepare("INSERT INTO produit (nom, prod_price,prod_pic, cat_id) VALUES (?,?,?, ?)");
//        $stmt->bindParam($name, $price, $cat_id);
//        $sql = "INSERT INTO produit(nom, prod_price) VALUES ('$name','$price')";
//        $query = mysqli_query($conn, $sql);
        if ($stmt->execute([$name, $price,$nameimage, $cat_id])) {
            echo "Inserted successfully";
        } else {
            die("error d'insertion ");
        }
    }
}
if (isset ($_GET["msg"]) && $_GET["msg"] == "2") {
    echo "<p style='color: green;'> produit bien2 modifié </p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>
</head>
<body>
<form action="insert.php" method="POST" enctype="multipart/form-data" class="form-group">
    <label for="">product name </label>
    <input type="text" name="name">
    <div style="color: red;"><?php echo $error["nameErr"]?? "" ;?></div>
<br>
<label for="">product price </label>
<input type="text" name="price">
<div style="color: red;"><?php echo $error["priceErr"]?? "" ;?></div>
<br>
<label for="" >categorie</label>
<select name="categorie">
    <?php
    $stmt = $conn->prepare("SELECT * FROM categorie");
    $stmt->execute();
//    $result = $stmt->get_result();
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<option value='".$row['id']."'>".$row['nom']."</option>";
    }
    ?>
</select>
    <label for="">product photo </label>
    <input type="file" name="image">
    <div style="color: red;"><?php echo $error["imageErr"]?? "" ;?></div>
<input type="submit" name="submit">
</form>
</body>
</html>

<?php
$stmt = $conn->prepare("select p.*, c.nom as cat_nom from produit p inner join categorie c on p.cat_id=c.id");
$stmt->execute();
//$result = $stmt->get_result();
//var_dump($result->fetch_all());
while ($row = $stmt->fetch(PDO::FETCH_OBJ)) {
//    var_dump($row);
    echo "<p> <img style='width:50px;' src='uploads/$row->prod_pic' alt=''><span> $row->id, $row->nom, $row->prod_price, $row->cat_nom  </span> <a href='remove.php?id=$row->id'>Remove</a> <a href='update.php?id=$row->id'>update</a> </p>";

}
$conn = null;
