<?php
include_once ("connection.php");
if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $stmt = $conn->prepare("select * from produit where id=?");
//    $stmt->bind_param("i", $id);
    if ($stmt->execute([$id])) {
//        $result = $stmt->get_result();
        $row = $stmt->fetch(PDO::FETCH_OBJ);

    }
}
if (isset($_POST["submit"])) {
    $id = $_POST["id"];
    $nom = $_POST["name"];
    $prix = $_POST["price"];
    $cat_id = $_POST["categorie"];
    $stmt = $conn->prepare("update produit set nom=?,prod_price=?, cat_id=? where id=?");
//    $stmt->bind_param("sdii", $nom, $prix,$cat_id, $id );
    if ($stmt->execute([$nom, $prix, $cat_id, $id])) {
        header("location:insert.php?msg=2");
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>
</head>
<body>
<form action="update.php" method="POST" class="form-group">
    <label for=""> id</label>
    <input type="text" name="id" value="<?= $row->id ?? "" ?>" readonly><br>
    <label for="">product name </label>
    <input type="text" name="name" value="<?= $row->nom ?? "" ?>"><br>
    <div style="color: red;"><?php echo $error["nameErr"]?? "" ;?></div>
    <br>
    <label for="">product price </label>
    <input type="text" name="price" value="<?= $row->prod_price ?? "" ?>"><br>
    <select name="categorie">
    <?php
    $stmt = $conn->prepare("SELECT * FROM categorie");
    $stmt->execute();
//    $result = $stmt->get_result();
    while ($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
        if ($r["id"] == $row->cat_id) {
            echo "<option value='".$r['id']."' selected>".$r['nom']."</option>";
        }else
            echo "<option value='".$r['id']."'>".$r['nom']."</option>";
    }
    ?>
    </select>

    <div style="color: red;"><?php echo $error["priceErr"]?? "" ;?></div>
    <br>
    <!--    <label for="">product photo </label>-->
    <!--    <input type="text" name="image">-->
    <!--    <div style="color: red;">--><?php //echo $error["imageErr"]?? "" ;?><!--</div>-->
    <input type="submit" name="submit">
</form>
</body>
</html>
