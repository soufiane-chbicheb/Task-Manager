<?php

include 'connection.php';

$nom = $_POST['nom'];
$email = $_POST['email'];

$sql = "INSERT INTO utilisateurs (nom, email) VALUES (?, ?)";
$stmt = $conn->prepare($sql);

if ($stmt) {
    $stmt->bind_param("ss", $nom, $email);
    if ($stmt->execute()) {
        echo "Nouvel enregistrement créé avec succès (POO - préparé). ID : 
" . $conn->insert_id . "<br>";
    } else {
        echo "Erreur lors de la création (POO - préparé) : " . $stmt->error
            . "<br>";
    }
    $stmt->close();
} else {
    echo "Erreur de préparation (POO) : " . $conn->error . "<br>";
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>
</head>
<body>
<form action="insert.php" method="POST" class="form-group">
    <label for="">product name </label>
    <input type="text" name="name">
    <div style="color: red;"><?php echo $error["nameErr"]?? "" ;?></div>
    <br>
    <label for="">product price </label>
    <input type="text" name="price">
    <div style="color: red;"><?php echo $error["priceErr"]?? "" ;?></div>
    <br>
<!--    <label for="">product photo </label>-->
<!--    <input type="text" name="image">-->
<!--    <div style="color: red;">--><?php //echo $error["imageErr"]?? "" ;?><!--</div>-->
    <input type="submit" name="submit">
</form>
</body>
</html>
