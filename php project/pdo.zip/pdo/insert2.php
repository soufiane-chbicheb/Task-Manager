<?php
include_once("connection.php");
$error = [];

if (isset($_POST["submit"])) {
    if (!empty($_POST["name"])) {
        $name = htmlspecialchars($_POST["name"]);
    } else {
        $error["nameErr"] = "Name of the product should not be empty";
    }

//    if (!empty($_POST["image"])) {
//        $image = htmlspecialchars($_POST["image"]);
//    } else {
//        $error["imageErr"] = "Image of the product should not be empty";
//    }

    if (!empty($_POST["price"])) {
        $price = htmlspecialchars($_POST["price"]);
    } else {
        $error["priceErr"] = "Price of the product should not be empty";
    }

    if (empty($error)) {
        $name = mysqli_real_escape_string($conn, $name);
        $price = mysqli_real_escape_string($conn, $price);
//        $image = mysqli_real_escape_string($conn, $image);
        $sql = "INSERT INTO produit(nom, prod_price) VALUES ('$name','$price')";
        $query = mysqli_query($conn, $sql);

        if ($query) {
            echo "Inserted successfully";
        } else {
            die("error : " . mysqli_error($conn));
        }
    }
}?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>
</head>
<body>
<form action="insert2.php" method="POST" class="form-group">
    <label for="">product name </label>
    <input type="text" name="name">
    <div style="color: red;"><?php echo $error["nameErr"]?? "" ;?></div>
<br>
<label for="">product price </label>
<input type="text" name="price">
<div style="color: red;"><?php echo $error["priceErr"]?? "" ;?></div>
<br>
<!--    <label for="">product photo </label>-->
<!--    <input type="text" name="image">-->
<!--    <div style="color: red;">--><?php //echo $error["imageErr"]?? "" ;?><!--</div>-->
<input type="submit" name="submit">
</form>
</body>
</html>