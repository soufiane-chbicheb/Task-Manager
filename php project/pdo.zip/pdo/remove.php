<?php
include_once ("connection.php");
if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $stmt = $conn->prepare("delete from produit where id=?");
//    $stmt->bindParam("i", $id);
    if ($stmt->execute([$id])) {
        echo "<script> alert('Product has been deleted') </script>";
        header(
            "location:insert.php"
        );
    }
}